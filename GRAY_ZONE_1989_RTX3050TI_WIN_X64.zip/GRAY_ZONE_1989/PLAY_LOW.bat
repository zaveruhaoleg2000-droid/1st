@echo off
cd /d "%~dp0"
set GZ_GPU_QUALITY=low
call "%~dp0PLAY.bat" %*
