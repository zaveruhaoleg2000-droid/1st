@echo off
cd /d "%~dp0"
if exist "%SystemRoot%\System32\vulkan-1.dll" (
  "%~dp0GRAY_ZONE_1989.exe" %*
) else (
  "%~dp0GRAY_ZONE_1989_CPU.exe" %*
)
