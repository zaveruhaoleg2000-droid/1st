@echo off
cd /d "%~dp0"
set GZ_GPU_QUALITY=high
call "%~dp0PLAY.bat" %*
