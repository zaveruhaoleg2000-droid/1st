@echo off
cd /d "%~dp0"
call "%~dp0PLAY.bat" --gpu-smoke-test
echo Exit code: %errorlevel%
pause
