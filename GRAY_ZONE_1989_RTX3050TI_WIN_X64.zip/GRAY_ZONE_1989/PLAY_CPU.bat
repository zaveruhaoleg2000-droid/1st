@echo off
cd /d "%~dp0"
"%~dp0GRAY_ZONE_1989_CPU.exe" %*
