@echo off
cd /d "%~dp0"
set GZ_GPU_QUALITY=medium
call "%~dp0PLAY.bat" %*
