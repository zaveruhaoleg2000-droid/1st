@echo off
cd /d "%~dp0"
"%~dp0grayzone_vulkan_probe.exe"
pause
